@extends('layouts.print')

@section('content')
    <div class="content">
        <invoices-print-component></invoices-print-component>
    </div>
@endsection

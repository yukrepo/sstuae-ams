@extends('layouts.print')

@section('content')
    <div class="content">
        <print-cform-component></print-cform-component>
    </div>
@endsection

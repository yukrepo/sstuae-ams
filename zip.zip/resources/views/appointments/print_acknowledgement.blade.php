@extends('layouts.print')

@section('content')
    <div class="content">
        <course-print-acknowledgement-component></course-print-acknowledgement-component>
    </div>
@endsection

@extends('layouts.print')

@section('content')
    <div class="content">
        <invoices-print-ipharmacy-component></invoices-print-ipharmacy-component>
    </div>
@endsection

@extends('layouts.print')

@section('content')
    <div class="content">
        <preapproval-courses-invoice-component></preapproval-courses-invoice-component>
    </div>
@endsection

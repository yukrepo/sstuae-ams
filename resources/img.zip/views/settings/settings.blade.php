@extends('layouts.main')

@section('content')
    <div class="content">
        <settings-profile-component></settings-profile-component>
    </div>
@endsection

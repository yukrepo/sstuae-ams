@extends('layouts.print')

@section('content')
    <div class="content">
        <dcourse-print-acknowledgement-component></dcourse-print-acknowledgement-component>
    </div>
@endsection

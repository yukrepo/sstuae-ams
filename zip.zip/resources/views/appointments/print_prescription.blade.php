@extends('layouts.print')

@section('content')
    <div class="content">
        <print-prescription-component></print-prescription-component>
    </div>
@endsection

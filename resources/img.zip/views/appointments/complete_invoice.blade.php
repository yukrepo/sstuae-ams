@extends('layouts.print')

@section('content')
    <div class="content">
        <appointment-complete-invoice-component></appointment-complete-invoice-component>
    </div>
@endsection

